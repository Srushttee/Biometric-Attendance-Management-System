<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct()
    {
        parent::__construct();
        //$this->load->helper('language_constants_helper');
        $this->load->model('Model');        
    }
	
	public function teacher_list($value='')
	{
		$data=$this->Model->get_status('first_name,last_name,id','teacher');

		if (!empty($data)) {
				$teacher = array('status' =>'1','data'=>$data );
				
			}else{
				$teacher = array('status' =>'0','msg'=>"No Data",'data'=> '');
			}
			print_r(json_encode($teacher));
	}


	public function class_list($value='')
	{
		$data=$this->Model->get_status('class,id','class');
		if (!empty($data)) {
				$teacher = array('status' =>'1','data'=>$data );
				
			}else{
				$teacher = array('status' =>'0','msg'=>"No Data",'data'=> '');
			}
		print_r(json_encode($teacher));
	}



	public function students_registration($value='')
	{
		$user_data = array('name' => $this->input->post('name'),'class_id' => $this->input->post('class_id'),'roll_no' => $this->input->post('roll_no'),'email' => $this->input->post('email'),'teacher_id' => $this->input->post('teacher_id'),'school_name' => $this->input->post('school_name'),'address' => $this->input->post('address'),'pincode' => $this->input->post('pincode'),'state' => $this->input->post('state'),'password' => $this->input->post('password'));
		$com = array('email' => $this->input->post('email'));
		$status=$this->Model->get_status('*','students',$com);
		if (empty($status)) {
				$id=$this->Model->insert('students',$user_data);
				$con = array('id' => $id, );
				$data=$this->Model->get_status('*','students',$con);
				$teacher = array('status' =>'1','msg'=>"Student Registered Successfully",'data'=>$data );
				
		}else{
			$teacher = array('status' =>'0','msg'=>"Email Already Registered",'data'=>'' );
		}
		print_r(json_encode($teacher));
	}


	public function attendance($value='')
	{
		$user_data = array('student_id' => $this->input->post('Student_id'),'lattitude' => $this->input->post('Lattitude'),'longitude' => $this->input->post('longitude'));
		
		$id=$this->Model->insert('attendance',$user_data);
		
		$teacher = array('status' =>'1','msg'=>"Attendance Successfully",'data'=>$id );
		
		print_r(json_encode($teacher));
	}
	
	
	public function login($value='')
	{
		//echo "hi";die;
		$user_data = array('email' => $this->input->post('email'),'password' => $this->input->post('password'));
		
		$status=$this->Model->get_status('*','students',$user_data);
		if (!empty($status)) {
			$teacher = array('status' =>'1','data'=>$status,'msg'=>'login successfully' );
		}else{
			$teacher = array('status' =>'0','msg'=>"Email Or Password Incorrect",'data'=>'' );
		}
		
		
		print_r(json_encode($teacher));
	}

	



}
