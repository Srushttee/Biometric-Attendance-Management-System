<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct()
    {
        parent::__construct();
        $this->load->model('Model');
        
    }
	

	public function index()
	{
		$data = array();
		
			$submit=$this->input->post('submit');
			if (isset($submit)) {
			if (!empty($this->input->post('username')) && !empty($this->input->post('password')) ) {
				$con = array('email' =>$this->input->post('username'),'password' =>$this->input->post('password'));
				if ($this->input->post('log_in_with')==1) {
					$status = $this->Model->get_status('*','admin',$con);
				}elseif ($this->input->post('log_in_with')==2) {
					$status = $this->Model->get_status('*','teacher',$con);
				}
				if (empty($status)) {
					$data['msg'] ="Invalid Login Details";
				}else{
						
					$this->session->set_userdata('logged_in',$status[0]);
						
					if ($this->input->post('log_in_with')==1) {
						redirect('dashboard');
					}elseif($this->input->post('log_in_with')==2) {
						redirect('user_dashboard');
					}						
				}
				
			}else{
				$data['msg'] ="Please Fill all Fileds";
			}
			}
			
			$this->load->view('admin/login',$data);		
		
	}
	
	public function dashboard($value='')
	{
			//print_r($this->session->userdata('logged_in'));die;	
			$data['class']=$this->Model->get_status_count('*','class');
			$data['teacher_count']=$this->Model->get_status_count('*','teacher');
			$data['teacher']=$this->Model->get_page_data('*','teacher','',10,0);
			$this->load->view('admin/dashboard',$data);
		
	}

	public function logout($value='')
	{
		$this->session->unset_userdata('logged_in');
		//$this->session->set_userdata('logged',false);
		redirect();
	}

	public function change_password($value='')
	{
		
			$data = array();
			$user_data['logged_in']=$this->session->userdata('logged_in');
			$submit=$this->input->post('submit');
			if (isset($submit)) {
				$con = array('email' => $user_data['logged_in']->email, 'password' =>$this->input->post('current_password'));
				$status = $this->Model->get_status('*','admin',$con);
				// print_r($status);
				// exit;
				if (!empty($status)) {
					if($this->input->post('password') == $this->input->post('c_password')){
						$user_data=array('password'=>$this->input->post('password'));
						$insert=$this->Model->updatedata('admin',$user_data,$con);
						$data['success']='Password changed successfully!';
						
					}else{
						$data['error']='New Password and Confirm password do not match!';
						
					}

				}else{
					$data['error']='Current Password do not match!';
					// print_r($data);
					// exit;
				}
			}
			
			$this->load->view('admin/change_password', $data);

			
	}

	public function profile($value='')
	{
		
			$submit=$this->input->post('submit');
			$user_data['logged_in']=$this->session->userdata('logged_in');
			$con = array('id' => $this->session->userdata('logged_in')->id) ;
			if (isset($submit)) {
				if (empty($_FILES['profile'])) {
					$img=$user_data['logged_in']->img;
				}else{
					$folder='assets/images/profile/';
					$img=$_FILES['profile']['name'];
					move_uploaded_file($_FILES["profile"]["tmp_name"], $folder.$img);
				}
				$data=array('name'=>$this->input->post('name'),'email'=>$this->input->post('email'),'img'=>$_FILES['profile']['name']);
			
				$data['msg']=$this->Model->updatedata('admin',$data,$con);
                //echo $this->db->last_query();die;
			}
			$logged_in=$this->Model->get_status('*','admin',$con);
			$this->session->set_userdata('logged_in',$logged_in[0]);
			$user_data['logged_in']=$this->session->userdata('logged_in');
			
			$this->load->view('admin/profile',$user_data);

				
		
	}

	public function teacher_master($value='')
	{
		
			//$where_in = array('status', ['1','0']);
			$data['users']=$this->Model->get_status('*','teacher');
			$con = array();
			
			$this->load->view('admin/teacher_master',$data);
		
		
	}

	public function add_teacher($value='')
	{
		
			$data=array();
			$where_in = array('status', ['1']);
			$con = array();
			$submit=$this->input->post('submit');
			$data['class'] = $this->Model->get_status('*','class');
			
			//$data['emails'] = $this->Model->get_status('email','users',$con);
			// echo "<pre>";
			// print_r($data['emails']);
			// exit;
			if (isset($submit)) {
				$con = array('email' =>$this->input->post('email'));
				$status = $this->Model->get_status('*','teacher',$con);
				
				if (empty($status)) {
					if($this->input->post('password') == $this->input->post('c_password')){
						$user_data=array('first_name'=>$this->input->post('first_name'),'last_name'=>$this->input->post('last_name'),'email'=>$this->input->post('email'),'password'=>$this->input->post('password'),'address'=>$this->input->post('address'),'class_id'=>$this->input->post('class_id'),'contact_number'=>$this->input->post('contact_number'));
						$insert=$this->Model->insert('teacher',$user_data);
						redirect('teacher_master');
						
					}else{
						$data['msg']='Password and Confirm password do not match!';
						
					}
										
				}else{
					$data['msg']='Email id alredy registered!';
				}
			}

			$this->load->view('admin/add_teacher',$data);	
		
	}

	public function edit_teacher($id='')
	{
		
			$con=array('id'=>$id);
			$data=array();
			$submit=$this->input->post('submit');
			if (isset($submit)) {
								#------Check user Status----------#
			//  $status = $this->Model->get_status('*','users',$con);
			//  if (empty($status)) {

					$user_data=array('first_name'=>$this->input->post('first_name'),'last_name'=>$this->input->post('last_name'),'email'=>$this->input->post('email'),'address'=>$this->input->post('address'),'class_id'=>$this->input->post('class_id'),'contact_number'=>$this->input->post('contact_number'),'status'=>$this->input->post('status'));
					$insert=$this->Model->updatedata('teacher',$user_data,$con);
					//redirect('users');
					
				//}else{
					$data['success']='User Updated Successfully';
				//}
			}
			$data['teacher'] = $this->Model->get_status('*','teacher',$con);
			$cons=array('status'=>'1');
			$data['class'] = $this->Model->get_status('*','class',$cons);

			$this->load->view('admin/edit_teacher',$data);
		
		
	}

	public function delete($value='')
	{
		
		$con = array('id' => $this->input->post('id'));
		if($this->Model->delete($this->input->post('table'),$con)){
			echo '1';
		}else{
			echo '2';
		}
		
		
	}

	public function class_master($value='')
	{
		
			// $where_in = array('status', ['1','0']);
			// $con = array();
			$data['class']=$this->Model->get_status('*','class');
			$this->load->view('admin/class_master',$data);
			
		
	}

	public function add_class($value='')
	{
		
			$submit=$this->input->post('submit');
			$data=array();
			if (isset($submit)) {
				$con = array('class' =>$this->input->post('name'));
								#------Check user Status----------#
				$status = $this->Model->get_status('*','class',$con);
				if (empty($status)) {

					$user_data=array('class'=>$this->input->post('name'));
					$insert=$this->Model->insert('class',$user_data);
					redirect('class_master');
					
				}else{
					$data['msg']='Class name already in use, Please use different name.';
				}
			}

			$this->load->view('admin/add_class',$data);			
		
		
	}

	public function edit_class($id='')
	{
		
			$submit=$this->input->post('submit');
			$con=array('id'=>$id);
			// print_r($con);
			// exit;
			$data=array();
			
			if (isset($submit)) {
				
				$user_data=array('class'=>$this->input->post('name'), 'status'=>$this->input->post('status'));
				$insert=$this->Model->updatedata('class',$user_data,$con);
				$data['msg']='Class Updated Successfully';
				redirect('class_master');
				
			}
			$data['user_data'] = $this->Model->get_status('*','class',$con);
			$this->load->view('admin/edit_class',$data);
		
		
	}
	
	public function student_list($id)
	{
			$con = array('teacher_id' =>$id , );
			$data['student']=$this->Model->get_status('*','students',$con);
			$this->load->view('admin/student_list',$data);
		
	}


}
