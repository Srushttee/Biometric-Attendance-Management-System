package info.androidhive.fingerprint;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class StudentRegistration extends AppCompatActivity {
    private View view;
    Spinner spinner_teacher,spinner_class;

    public static SharedPreferences sharedpreferences;
    String UserId="",Name="",Address="",Mobile="",Email="",Token="";
    EditText edt_cust_name,edt_cust_email,edt_rollno,edt_cust_address,edt_school_name,
            edt_pincode,edt_state,edt_password;
    private String DistrictId="";
    private String TalukaId="",VillageId="";
    private ProgressDialog progressDoalog;
    private JSONObject jsonObject1;
    TextView txt_send;
    ArrayList<CommonClass>teacherlist=new ArrayList<>();
    ArrayList<CommonClass>classlist=new ArrayList<>();
    private CommonAdapter commonAdapter;
    private String class_id;
    private String teacher_id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_reg_lay);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        sharedpreferences = getSharedPreferences("LoggingPrefs", MODE_PRIVATE);

        edt_cust_name = findViewById(R.id.edt_name);
        edt_cust_email = findViewById(R.id.edt_email);
        edt_rollno = findViewById(R.id.edt_rollno);
        edt_cust_address = findViewById(R.id.edt_address);
        edt_school_name = findViewById(R.id.edt_school_name);
        edt_pincode = findViewById(R.id.edt_pincode);
        edt_state = findViewById(R.id.edt_state);
        edt_password = findViewById(R.id.edt_password);
        txt_send = findViewById(R.id.txt_send);
        spinner_teacher = findViewById(R.id.spinner_teacher);
        spinner_class = findViewById(R.id.spinner_class);

        getteacher();
        getclass();



        spinner_teacher.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                teacher_id=teacherlist.get(position).getId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner_class.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                class_id=classlist.get(position).getId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        txt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customerregistration();
            }
        });

    }




    private void customerregistration(){


        progressDoalog = new ProgressDialog(StudentRegistration.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.setTitle("Request sending ...");
        progressDoalog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDoalog.show();

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("name",edt_cust_name.getText().toString())
                .addFormDataPart("roll_no",edt_rollno.getText().toString())
                .addFormDataPart("email",edt_cust_email.getText().toString())
                .addFormDataPart("school_name",edt_school_name.getText().toString())
                .addFormDataPart("address",edt_cust_address.getText().toString())
                .addFormDataPart("pincode",edt_pincode.getText().toString())
                .addFormDataPart("state",edt_state.getText().toString())
                .addFormDataPart("class_id",class_id)
                .addFormDataPart("teacher_id",teacher_id)
                .addFormDataPart("password",edt_password.getText().toString())
                .build();
        Request request = new Request.Builder()
                // .url("http://44.203.141.165/Api/add_tree_data")
                .url("https://teacher.debuglayer.com/Api/students_registration")
                .method("POST", body)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                try {

                    final JSONObject jsonObject=new JSONObject(response.body().string());
                    String Status=jsonObject.getString("status");
                    final String Msg=jsonObject.getString("msg");
                    if (Status.equalsIgnoreCase("1")){
                        progressDoalog.dismiss();
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(StudentRegistration.this, Msg, Toast.LENGTH_LONG).show();
                                JSONArray jsonArray= null;
                                try {
                                    jsonArray = jsonObject.getJSONArray("data");
                                    for (int i=0;i<jsonArray.length();i++){
                                        JSONObject jsonObject1=jsonArray.getJSONObject(i);
                                        String id=jsonObject1.getString("id");
                                        String name=jsonObject1.getString("name");
                                        String email=jsonObject1.getString("email");
                                        String roll_no=jsonObject1.getString("roll_no");
                                        SharedPreferences.Editor editor = sharedpreferences.edit();
                                        editor.putString("user",id);
                                        editor.putString("name",name);
                                        editor.putString("email",email);
                                        editor.putString("mobile",roll_no);
                                        editor.commit();
                                        startActivity(new Intent(StudentRegistration.this,FingerprintActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                        finish();

                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }



                            }
                        });


                    }else {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(StudentRegistration.this, Msg, Toast.LENGTH_LONG).show();

                            }
                        });
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }
    private void getteacher() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                // .url("http://44.203.141.165/Api/add_tree_data")
                .url("https://teacher.debuglayer.com/Api/teacher_list")
                .method("GET", null)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                try {

                    final JSONObject jsonObject=new JSONObject(response.body().string());
                    String Status=jsonObject.getString("status");
                    if (Status.equalsIgnoreCase("1")){
                        runOnUiThread(new Runnable() {
                            public void run() {
                                try {
                                    teacherlist.clear();
                                    JSONArray jsonArray=jsonObject.getJSONArray("data");
                                    for (int i=0;i<jsonArray.length();i++){
                                        CommonClass commonClass=new CommonClass();
                                        JSONObject jsonObject1=jsonArray.getJSONObject(i);
                                        commonClass.setId(jsonObject1.getString("id"));
                                        commonClass.setName(jsonObject1.getString("first_name")+" "+jsonObject1.getString("last_name"));
                                        teacherlist.add(commonClass);

                                    }

                                    commonAdapter=new CommonAdapter(StudentRegistration.this,teacherlist);
                                    spinner_teacher.setAdapter(commonAdapter);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });


                    }else {
                        runOnUiThread(new Runnable() {
                            public void run() {

                            }
                        });
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }
    private void getclass() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                // .url("http://44.203.141.165/Api/add_tree_data")
                .url("https://teacher.debuglayer.com/Api/class_list")
                .method("GET", null)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                try {

                    final JSONObject jsonObject=new JSONObject(response.body().string());
                    String Status=jsonObject.getString("status");
                    if (Status.equalsIgnoreCase("1")){
                        runOnUiThread(new Runnable() {
                            public void run() {
                                try {
                                    classlist.clear();
                                    JSONArray jsonArray=jsonObject.getJSONArray("data");
                                    for (int i=0;i<jsonArray.length();i++){
                                        CommonClass commonClass=new CommonClass();
                                        JSONObject jsonObject1=jsonArray.getJSONObject(i);
                                        commonClass.setId(jsonObject1.getString("id"));
                                        commonClass.setName(jsonObject1.getString("class"));
                                        classlist.add(commonClass);

                                    }

                                    commonAdapter=new CommonAdapter(StudentRegistration.this,classlist);
                                    spinner_class.setAdapter(commonAdapter);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });


                    }else {
                        runOnUiThread(new Runnable() {
                            public void run() {

                            }
                        });
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }



}