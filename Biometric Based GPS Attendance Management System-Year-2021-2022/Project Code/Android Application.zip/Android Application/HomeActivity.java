package info.androidhive.fingerprint;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class HomeActivity extends AppCompatActivity {


    public static SharedPreferences sharedpreferences;
    private ProgressDialog progressDoalog;
    private String UserId="",Lattitude="",Longitude="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        sharedpreferences = getSharedPreferences("LoggingPrefs", MODE_PRIVATE);
        UserId=sharedpreferences.getString("user","");
        Lattitude=sharedpreferences.getString("lat","");
        Longitude=sharedpreferences.getString("lng","");
        Validatelogin();
    }

    private void Validatelogin(){


        progressDoalog = new ProgressDialog(HomeActivity.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.setTitle("Request sending ...");
        progressDoalog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDoalog.show();

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("Student_id",UserId)
                .addFormDataPart("Lattitude",Lattitude)
                .addFormDataPart("longitude",Longitude)
                .build();
        Request request = new Request.Builder()
                .url("https://teacher.debuglayer.com/Api/attendance")
                .method("POST", body)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {

                try {

                    final JSONObject jsonObject=new JSONObject(response.body().string());
                    String Status=jsonObject.getString("status");
                    final String Msg=jsonObject.getString("msg");
                    if (Status.equalsIgnoreCase("1")){
                        progressDoalog.dismiss();
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(HomeActivity.this, Msg, Toast.LENGTH_LONG).show();

                            }
                        });


                    }else {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(HomeActivity.this, Msg, Toast.LENGTH_LONG).show();

                            }
                        });
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }

}
